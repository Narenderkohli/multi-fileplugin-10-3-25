<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uploadcare Photo Collage</title>
    <script src="https://ucarecdn.com/libs/widget/3.x/uploadcare.full.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
       // UPLOADCARE_PUBLIC_KEY = '0eac30b06d6fb00f6528';
       UPLOADCARE_PUBLIC_KEY = 'e383c9ab5c188e59a9e2';
    </script>
    <style>
        body {
                font-family: Arial, sans-serif;
                text-align: center;
          }
        .upload-image-btn {
            background: green;
            color: white;
            width: 34%;
            text-transform: capitalize;
            margin: 20px;
            cursor: pointer;
        }
        #collage {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            width: 400px;
            border: 2px solid #333;
            margin: 20px auto;
            padding: 10px;
            background: #f9f9f9;
        }
        .collage-item {
            width: 100%;
            height: auto;
            max-height: 150px;
            object-fit: cover;
            cursor: grab;
            user-select: none;
        }
        #merged-image-link {
            display: block;
            margin-top: 10px;
            font-size: 14px;
        }
        .up-btn-main {
                    display: block;
                    justify-items: center;
                }
    </style>
</head>
<body>

    <h5>Upload Multiple Photos for Collage</h5>

            <?php
            $min_images = get_option('mfu_min_images', 4);
            $max_images = get_option('mfu_max_images', 4);
            ?>
    
    <div class="image-preview-multiple">
        <input type="hidden" role="uploadcare-uploader" data-multiple="true" data-images-only="true" 
          data-multiple-min="<?php echo esc_attr($min_images); ?>" 
          data-multiple-max="<?php echo esc_attr($max_images); ?>" 
          data-live="true"
         id="uploadcare-widget"  data-crop="16:9, 4:3, 1:1"/>
        <div id="collage" ondrop="drop(event)" ondragover="allowDrop(event)"></div>
    </div>


     <div class="up-btn-main"> 

    <div class="upload-image-btn" onclick="mergeImages()" style="display:none;">upload Final Image</div>

    </div>

    <script>
                jQuery(".image-preview-multiple").on("click", function() {
                    setTimeout(function () {

                var interval = setInterval(function() {  
                var button = jQuery(".uploadcare--footer__button");
                if (button.is(":disabled")) {
                      jQuery("#add-more-btn").show();
                    //console.log("Uploadcare button is disabled");

                } else {
                      jQuery("#add-more-btn").hide();
                    //console.log("Uploadcare button is enabled. Stopping interval.");
                    clearInterval(interval); 
                }
                }, 1000); 
                     
                 var previewTab = jQuery('.uploadcare--tab__header'); //added the add more images button
                    jQuery(".uploadcare--button_primary").text("Add Frame");
                    if (jQuery("#add-more-btn").length === 0) {
                        var addMoreButton = jQuery('<button id="add-more-btn">Add More Images</button>')
                            .css({
                                "display": "block",
                                "margin": "10px auto",
                                "padding": "8px",
                                "cursor": "pointer",
                                "background": "#0073e6",
                                "color": "#fff",
                                "border": "none",
                                "border-radius": "5px"
                            })
                            .click(function () {
                                 $(".uploadcare--button_size_big").click();
                           });

                        previewTab.append(addMoreButton);
                    }
                }, 2000);
             });

        // if you delete image from the dashborad check again
            jQuery(document).on("click", ".uploadcare--button_icon", function() {
             var interval = setInterval(function() {
            var button = jQuery(".uploadcare--footer__button");
            if (button.is(":disabled")) {
            jQuery("#add-more-btn").show();
            //console.log("Uploadcare button is disabled");

            } else {
            jQuery("#add-more-btn").hide();
            //console.log("Uploadcare button is enabled. Stopping interval.");
            clearInterval(interval); 
            }
            }, 1000); 
            });


   $(function () {
            installWidgetPreviewMultiple(
                uploadcare.MultipleWidget($('#uploadcare-widget')),
                $('#collage')

            );
        });

        function installWidgetPreviewMultiple(widget, list) {
            widget.onChange(function (fileGroup) {
                list.empty();
                if (fileGroup) {
                    $.when.apply(null, fileGroup.files()).done(function () {
                        $.each(arguments, function (i, fileInfo) {
                            var src = fileInfo.cdnUrl;
                            var img = $("<img/>", {
                                src: src,
                                class: "collage-item",
                                draggable: true,
                                id: "img-" + i,
                                crossOrigin: "anonymous",
                                ondragstart: "drag(event)"
                            });
                            list.append(img);
                        });
                    });
                }
            });
        }

        function allowDrop(event) {
            event.preventDefault();
        }

        function drag(event) {
            event.dataTransfer.setData("text", event.target.id);
        }

        function drop(event) {
            event.preventDefault();
            var draggedId = event.dataTransfer.getData("text");
            var draggedElement = document.getElementById(draggedId);
            var targetElement = event.target;

            if (targetElement.classList.contains("collage-item") && draggedElement !== targetElement) {
                var collageContainer = document.getElementById("collage");
                var allImages = Array.from(collageContainer.children);
                var draggedIndex = allImages.indexOf(draggedElement);
                var targetIndex = allImages.indexOf(targetElement);

                // if (draggedIndex < targetIndex) {
                //     targetElement.insertAdjacentElement('afterend', draggedElement);
                // } else {
                //     targetElement.insertAdjacentElement('beforebegin', draggedElement);
                // }
            }
        }

        function mergeImages() {
            var collageContainer = document.getElementById("collage");
            var images = collageContainer.getElementsByTagName("img");
            var canvas = document.createElement("canvas");
            var ctx = canvas.getContext("2d");

            // if (images.length === 0) {
            //     alert("Please upload some images first!");
            //     return;
            // }

            canvas.width = 400;
            canvas.height = 400;
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            var gridSize = Math.ceil(Math.sqrt(images.length));
            var imgSize = canvas.width / gridSize;

            let loadedImages = 0;

            for (let i = 0; i < images.length; i++) {
                let img = new Image();
                img.crossOrigin = "anonymous";
                img.src = images[i].src;

                img.onload = function () {
                    var x = (i % gridSize) * imgSize;
                    var y = Math.floor(i / gridSize) * imgSize;
                    ctx.drawImage(img, x, y, imgSize, imgSize);

                    loadedImages++;
                    if (loadedImages === images.length) {
                        var mergedImageData = canvas.toDataURL("image/png");

                        // Convert Data URL to File and Set it in Input Field
                        dataURLtoFile(mergedImageData, "merged_image.png");

                        // Set Download Link
                        setDownloadLink(mergedImageData, "merged_image.png");
                    }
                };

                img.onerror = function () {
                    console.error("Failed to load image:", images[i].src);
                };
            }
        }

           // Triger the merage image function on click Add button 
            document.addEventListener("DOMContentLoaded", function () {
            document.addEventListener("click", function (event) {
                if (event.target.classList.contains("uploadcare--button")) {
                    setTimeout(function () {
                        console.log("image merge code runing ");
                        mergeImages(); 
                    }, 3000);
                }
            });
            });


        function dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(","),
                mime = arr[0].match(/:(.*?);/)[1],
                bstr = atob(arr[1]),
                n = bstr.length,
                u8arr = new Uint8Array(n);

            while (n--) {
                u8arr[n] = bstr.charCodeAt(n);
            }

            var file = new File([u8arr], filename, { type: mime });

            // Set the file into input field
            var inputElement = document.getElementById("custom_image");

            // Creating a DataTransfer object to assign the file to input
            var dataTransfer = new DataTransfer();
            dataTransfer.items.add(file);
            inputElement.files = dataTransfer.files;

            console.log("Final Image Uploaded successfully");
        }

        function setDownloadLink(imageData, filename) {
            var link = document.getElementById("merged-image-link");
            link.href = imageData;
            link.download = filename;
            link.textContent = filename;
            link.style.display = "none";
        }


   
    </script>

</body>
</html>
